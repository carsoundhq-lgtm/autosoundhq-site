# AutoSoundHQ — Static v0 (Ready for Vercel)

Prewired static site with **Google Analytics** (`G-ZC0NKMJFZF`) and **Skimlinks** (`292632X1779781`), plus Amazon affiliate tags (`autosoundhq-20`).

## Deploy on Vercel (2 minutes)
1. Create a repo on GitHub under your account `carsoundhq-lgtm` (e.g., `autosoundhq-site`).
2. Upload all files from this ZIP to that repo (drag-and-drop on GitHub web works).
3. Go to https://vercel.com → **New Project** → **Import Git Repository** → select your repo.
4. Framework preset: **Other** (static). Build command: **None**. Output directory: `/`.
5. Click **Deploy**. Your site will be live at a Vercel URL you can rename to `autosoundhq.vercel.app`.
6. Add a custom domain later if you want.
